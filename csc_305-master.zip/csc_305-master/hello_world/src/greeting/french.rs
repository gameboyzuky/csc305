pub(crate) fn greet_french(){
    println!("Bonjour");
}